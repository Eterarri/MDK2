﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EX5
{
    class Program
    {
        static void Main(string[] args)
        {
            double a = 0.1;
            for (double i = 0; i < 0.8; i += 0.1)
            {                
                Console.WriteLine($"√{a+i}");
            }
            Console.ReadLine();
        }
    }
}
