﻿using System;
namespace EX3
{
    class Program    
    {
        static void Main(string[] args)
        {
            bool x = false;
            bool y = false;
            Console.WriteLine("X = False;\nY = False;");
            bool result1 = !(!x || y) || !x;
            bool result2 = !(!x & !y) & x;
            bool result3 = !(x || !y)|| !y;
            Console.WriteLine($"не (не X или Y) или не X. Вывод : {result1};") ;          
            Console.WriteLine($"не (не X и не Y) и X. Вывод : {result2};");
            Console.WriteLine($"не (X или не Y) или не Y. Вывод : {result3};");
            Console.ReadKey();            
        }
    }
}
