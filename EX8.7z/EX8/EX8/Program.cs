﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq;

namespace EX8
{
    class Program
    {
        static double[] mass = new double[10];
        static double[] mass1 = new double[10];
        static double[] mass2 = new double[10];
        static Random random = new Random();
        
        static void Main(string[] args)
        {
            for (int i = 0; i < mass.Length; i++)
            {
                mass[i] = random.Next(1, 231);
                mass1[i] = random.Next(1, 231);
                mass2[i] = random.Next(1, 231);
            }

            Console.WriteLine("Магазины заполнены");

            for (int i = 0; i < mass.Length; i++)
            {
                Console.WriteLine(mass[i] + "\t" + mass1[i] + "\t" + mass2[i]) ;
            }

            if (mass.Sum() > mass1.Sum() && mass.Sum() > mass2.Sum())
                Console.WriteLine("1й магазин получил доход больше остальных;");
            else if (mass1.Sum() > mass.Sum() && mass1.Sum() > mass2.Sum())
                Console.WriteLine("2й магазин получил доход больше остальных;");
            else
                Console.WriteLine("3й магазин получил доход больше остальных;");

            double[] temp = new double[mass.Length];

            for (int i = 0; i < mass.Length; i++)
                temp[i] = mass[i] + mass1[i] + mass2[i];

            double res = 0;
            for (int i = 0; i < mass.Length -1; i++)
            {
                if (temp[i] > temp[i + 1])
                    res = i;
            }
            Console.WriteLine(res + 1);

            Console.ReadLine();
        }
       
    }
}
