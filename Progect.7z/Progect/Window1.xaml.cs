﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Progect
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public List<string> Log = new List<string>();
        public List<string> Pass = new List<string>();
        public List<string> email = new List<string>();
               
        public Window1()
        {
            InitializeComponent();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (TextBox1.Text != "" && TextBox2.Text != "" && Textbox3.Text != "")
            {
                if (TextBox1 != null && TextBox2 != null && Textbox3 != null)
                {
                    Log.Add(TextBox1.Text);
                    Pass.Add(TextBox2.Text);
                    email.Add(Textbox3.Text);
                }
            }
            else
                MessageBox.Show("Неккоректно введены поля проверьте их на пустоту.");
            this.Hide();
            TextBox1.Clear();
            TextBox2.Clear();
            Textbox3.Clear();
        }
    }
}
