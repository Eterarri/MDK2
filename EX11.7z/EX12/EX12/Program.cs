﻿using System;
using System.Data;
namespace EX12
{
    class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            int lenght = 999;
            int[] a = new int[lenght];
            string temp = string.Empty;
            for (int i = 0; i < lenght; i++)
            {
                a[i] = random.Next(1, 100);

                if (i % 2 == 0)
                   temp += a[i] + "-";
                else
                   temp += a[i] + "+";
            }
            temp = temp.TrimEnd('+','-');
            Console.WriteLine(temp);
            Console.WriteLine(new DataTable().Compute(temp, null));
            Console.ReadKey();
        }
    }
}
