﻿using System;
namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime date = new DateTime(1990,1,1);
            Console.WriteLine("Изначальная дата " + date.ToShortDateString());
            Console.Write($"Прибавить к {date.ToShortDateString()}; 2 дня и месяцев: ");
            date = date.AddDays(2);
            date = date.AddMonths(int.Parse(Console.ReadLine()));
            Console.WriteLine("\n" + date.ToShortDateString());
            Console.ReadKey();
        }
    }
}
