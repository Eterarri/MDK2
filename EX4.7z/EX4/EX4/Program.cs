﻿using System;
namespace EX4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите 1-е число\t");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите 2-е число");
            int b = int.Parse(Console.ReadLine());
            int result = a / b;
            if (result == 0)
            {
                 Console.WriteLine($"Число {a} на число {b} нацело не делится");
            }
            else
            {
                Console.WriteLine($"Ваше частное от деления = {result}");
            }
            Console.ReadLine();            
        }
    }
}
