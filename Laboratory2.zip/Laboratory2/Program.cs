﻿using System;
namespace Laboratory2
{
    class Program
    {
        static void Main(string[] args)
        {
            const double accuracy = 0.003;
            double intervala;
            double intervalb;
            intervala = -3;
            intervalb = -1;
            while (intervalb - intervala > accuracy)
            {
                double c = (intervala + intervalb) / 2;
                if (DerivativeForX(intervalb) * DerivativeForX(c) < 0)
                    intervala = c;
                else
                    intervalb = c;
            }
            Console.WriteLine((intervala + intervalb) / 2);
            Console.ReadKey();
        }
        static double DerivativeForX(double x)
        {          
            double left = 10d * Math.Cos(x);
            double right = Math.Sin(x) + Math.Pow(Math.E, x);
            return left * right;
        }
    }
}
