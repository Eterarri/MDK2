﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace AutoServise
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {

        Model model = new Model();
        public Window1()
        {
            InitializeComponent();
        }

        private void Button_addName_Click(object sender, RoutedEventArgs e)
        {
            model.NameFio = TextBoxName.Text;   
            ListView.Items.Add(model.NameFio);
        }

        private void Batton_add_Click(object sender, RoutedEventArgs e)
        {
            ListView.Items.Clear();
            
        }

        private void Button_addDate_Click(object sender, RoutedEventArgs e)
        {
            ListView.Items.Add(model.CreationData.ToShortDateString());
        }

        private void Button_addCar_Click(object sender, RoutedEventArgs e)
        {
            model.NameCar = TextBoxNameCar.Text;
            ListView.Items.Add(model.NameCar);
        }

        private void Button_addWork_Click(object sender, RoutedEventArgs e)
        {
            model.TypeWork = TextBoxNameTypework.Text;
            ListView.Items.Add(model.TypeWork);
        }

        private void Button_addRepairMoney_Click(object sender, RoutedEventArgs e)
        {
            model.RepairCost = TextBoxNameRepair.Text;
            ListView.Items.Add(model.RepairCost);
        }
    }
}
