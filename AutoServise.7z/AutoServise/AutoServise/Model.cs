﻿using System;

namespace AutoServise
{
    class Model
    {
        public DateTime CreationData { get; set; } = DateTime.Now;
        public string NameFio { get; set; }
        public string TypeWork { get; set; }
        public string NameCar { get; set; }
        public string RepairCost { get; set; }


    }
}
