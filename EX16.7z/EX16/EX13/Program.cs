﻿using System;
namespace EX13
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] mass = new int[30];
            Random random = new Random();

            for (int i = 0; i < mass.Length; i++)
            {
                mass[i] = random.Next(1, 5);
                if (mass[i] % 2 != 0)
                {
                    Console.WriteLine(mass[i]);
                }
            }
            Console.ReadKey();
        }
    }
}
