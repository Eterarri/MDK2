﻿using System;
namespace EX1
{
    class Program
    {
        static void Main(string[] args)
        {
            QuestA();
            QuestB();
            Console.ReadLine();
        }
        static void QuestA()
        {
            int s = 14;
            int k = -3;
            int d = s + 1;
            s = d;
            k = 2 * s;
            Console.WriteLine($"Результат k = {k}, Результат s = {s}");        
        }
        static void QuestB()
        {
            int s = 0;
            int k = 30;
            int d = k-5;
            s = k-100;
            k = 2 * d;
            Console.WriteLine($"Результат k = {k}, Результат s = {s}");           
        }
    }
}
