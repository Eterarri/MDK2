﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EX1._42
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите значения e,f,g и h для счёта функций");
            double e = double.Parse(Console.ReadLine());
            double f = double.Parse(Console.ReadLine());
            double g = double.Parse(Console.ReadLine());
            double h = double.Parse(Console.ReadLine());
            Console.WriteLine("Введите функицю которую хотите расчитать\n1 = Найти A\n" +
                "2 = Найти B\n3 = Найти C");
            int choise = int.Parse(Console.ReadLine());
            switch (choise)
            {
                case 1:
                    Console.WriteLine($"А = {MethodA(e,f)}") ;
                    break;
                case 2:
                    Console.WriteLine($"B = {MethodB(h, g)}");
                    break;
                case 3:
                    Console.WriteLine($"C = {MethodC(g, h, e)}");
                    break;
            }
            Console.ReadKey();
        }
        static double MethodA(double e, double f)
        {
            return (e + f / 2) / 3;           
        }
        static double MethodB(double h, double g)
        {
            return Math.Abs(Math.Pow(h, 2) - g);
        }
        static double MethodC(double g , double h, double e)
        {
            return Math.Sqrt(Math.Pow(g - h, 2) - 3 * Math.Sin(e));
        }
    }
}
