﻿using System;
namespace EX2
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 2;
            int b = 3;
            int c = 5;
            int d = 9;
            Console.WriteLine($"Дано число : {a}{b}{c}{d}") ;
            Console.WriteLine($"Справа налево : {d}{c}{b}{a}") ;
            Console.WriteLine($"Число, образуемое при перестановке первой и второй, третьей и четвертой : {b}{a}{d}{c}") ;
            Console.ReadLine();
        }
    }
}
