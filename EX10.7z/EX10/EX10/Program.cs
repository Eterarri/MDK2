﻿using System;
using System.Collections.Generic;
namespace EX10
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> chislo = new List<int>();

            foreach (var item in Console.ReadLine())
            {
                if (int.TryParse(item.ToString(),out int rez))
                    chislo.Add(rez);
            }
            if (chislo.Count != 6)
                return;
                      
            if (chislo[0] + chislo[1] + chislo[2] == chislo[3] + chislo[4] + chislo[5])
                Console.WriteLine($"Вы получили счастливое число");
            Console.ReadLine();                     
        }
    }
}
