﻿using System;
namespace EX9
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите слово : ");
            string a = Console.ReadLine();
            Console.WriteLine($"Второй символ: {a[1]} , Четвёртый символ: {a[3]}");
        }
    }
}
